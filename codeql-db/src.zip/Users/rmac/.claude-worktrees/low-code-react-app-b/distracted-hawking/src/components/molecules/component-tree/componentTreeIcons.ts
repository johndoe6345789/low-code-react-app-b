import { Tree } from '@phosphor-icons/react'

export const componentTreeIcons = {
  tree: Tree,
}
