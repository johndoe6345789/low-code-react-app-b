import { SeedDataManager } from '@/components/molecules'

export function DataTab() {
  return (
    <div className="max-w-2xl">
      <SeedDataManager />
    </div>
  )
}
