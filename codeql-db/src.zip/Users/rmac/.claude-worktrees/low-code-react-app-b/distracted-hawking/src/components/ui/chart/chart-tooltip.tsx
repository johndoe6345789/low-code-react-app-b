import * as RechartsPrimitive from "recharts"

const ChartTooltip = RechartsPrimitive.Tooltip

export { ChartTooltip }
