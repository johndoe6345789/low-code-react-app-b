import * as RechartsPrimitive from "recharts"

const ChartLegend = RechartsPrimitive.Legend

export { ChartLegend }
