import { FormProvider } from "react-hook-form"

const Form = FormProvider

export { Form }
