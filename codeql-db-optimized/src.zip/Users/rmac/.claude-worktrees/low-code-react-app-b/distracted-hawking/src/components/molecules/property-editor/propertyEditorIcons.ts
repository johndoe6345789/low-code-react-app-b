import { Sliders } from '@phosphor-icons/react'

export const propertyEditorIcons = {
  sliders: Sliders,
}
