import AppBootstrap from '@/components/app/AppBootstrap'

export default function App() {
  return <AppBootstrap />
}
