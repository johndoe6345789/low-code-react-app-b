import AppRouterBootstrap from '@/components/app/AppRouterBootstrap'

export default function App() {
  return <AppRouterBootstrap />
}
