export { default as ecommerceTemplate } from './e-commerce.json'
export { default as blogTemplate } from './blog.json'
export { default as dashboardTemplate } from './dashboard.json'
