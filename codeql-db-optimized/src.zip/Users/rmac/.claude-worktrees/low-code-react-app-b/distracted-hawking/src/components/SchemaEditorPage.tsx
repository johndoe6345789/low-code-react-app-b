import { SchemaEditorWorkspace } from '@/components/schema-editor/SchemaEditorWorkspace'

export function SchemaEditorPage() {
  return <SchemaEditorWorkspace />
}
